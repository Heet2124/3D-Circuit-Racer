# 3D Circuit Racer — PyOpenGL Computer Graphics Mini Project

A simple, playable 3D closed-circuit racing game made with Python, Pygame and PyOpenGL. It is designed to demonstrate fundamental Computer Graphics concepts in code that is approachable for a college viva.

## Features
- 3D oval circuit with asphalt, curbs, center dashes, start/finish line, trees and grandstands
- Player car plus 3 AI competitors
- Countdown, race timer, 3-lap race and lap timing
- Checkpoint-sector display and live race order
- Speed, acceleration, braking, steering and collision slow-down
- Follow camera, start screen, pause/resume, finish screen and restart
- Cube-based car models built using OpenGL translation, rotation and scaling

## Requirements
- Windows 10/11
- Python 3.10 or newer (64-bit recommended)
- A graphics driver supporting legacy OpenGL

## Install and run (PowerShell)
Open PowerShell and run these commands:

```powershell
cd "C:\Users\heets\Downloads\collge projects\3D Racing Car"
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

If PowerShell blocks activation, use Command Prompt instead:
```bat
cd /d "C:\Users\heets\Downloads\collge projects\3D Racing Car"
py -m venv .venv
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

If `PyOpenGL_accelerate` fails to install, remove that line from `requirements.txt` and run `pip install -r requirements.txt` again. It is optional; PyOpenGL works without it.

## Controls
- Enter: start countdown
- W / Up Arrow: accelerate
- S / Down Arrow: brake / slow reverse
- A / Left Arrow: steer left across the road
- D / Right Arrow: steer right across the road
- Space: pause / resume
- R: restart the race
- Esc: quit

## How the code works
1. Pygame creates the window and reads keyboard events.
2. PyOpenGL draws the ground, oval track, trees and cube-based cars.
3. Each frame, `update()` changes the player's speed, lane and track angle, then advances the AI cars.
4. `update_laps()` detects when a racer crosses the start/finish point and updates lap timing.
5. `handle_collisions()` checks distance between the player and rival cars and slows the player on contact.
6. The camera follows behind the player using `gluLookAt()`.
7. The HUD is drawn in a 2D overlay after the 3D scene.

## Computer Graphics concepts for the report/viva
- Translation: `glTranslatef(x, y, z)` positions a model.
- Rotation: `glRotatef(angle, x, y, z)` rotates a model around an axis.
- Scaling: `glScalef(sx, sy, sz)` changes a model's dimensions.
- Perspective projection: `gluPerspective()` gives a 3D perspective view.
- Camera/view transformation: `gluLookAt()` sets the camera eye and target.
- Depth buffer: `glEnable(GL_DEPTH_TEST)` ensures closer objects hide farther ones.
- Lighting: `GL_LIGHTING`, `GL_LIGHT0` and normals add depth cues.
- Animation/game loop: frame delta time (`dt`) makes movement less dependent on frame rate.

## Notes
This is a learning-oriented mini-project, not a professional racing simulator. The AI uses a lightweight oval-track model and simple distance-based collision response. The checkpoint indicator divides the lap into four sectors.
