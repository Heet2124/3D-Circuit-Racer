"""
3D CIRCUIT RACER — Computer Graphics Mini Project
Python + Pygame + PyOpenGL

Controls:
  W / UP       Accelerate
  S / DOWN     Brake / reverse slowly
  A / LEFT     Steer left
  D / RIGHT    Steer right
  SPACE        Pause / resume
  R            Restart race
  ESC          Quit

Computer Graphics concepts demonstrated:
  - glTranslatef: position objects in the 3D world
  - glRotatef: orient cars and wheels
  - glScalef: build cars from scaled cubes
  - gluPerspective: perspective projection
  - GL_DEPTH_TEST: correct front-to-back visibility
  - lighting, normals, color, viewport, and double buffering
"""

import math
import random
import sys
import pygame
from pygame.locals import DOUBLEBUF, OPENGL
from OpenGL.GL import *
from OpenGL.GLU import *

# ------------------------------ SETTINGS -----------------------------------
WIDTH, HEIGHT = 1280, 720
FPS = 60
TOTAL_LAPS = 3
TRACK_A = 42.0                 # oval radius along world X
TRACK_B = 27.0                 # oval radius along world Z
ROAD_WIDTH = 10.0
INNER_A = TRACK_A - ROAD_WIDTH / 2
OUTER_A = TRACK_A + ROAD_WIDTH / 2
INNER_B = TRACK_B - ROAD_WIDTH / 2
OUTER_B = TRACK_B + ROAD_WIDTH / 2
MAX_SPEED = 31.0               # world units / second
ACCELERATION = 15.0
BRAKING = 25.0
DRAG = 5.0
STEER_RATE = 0.95              # lane offset speed
LANE_LIMIT = ROAD_WIDTH * 0.39
AI_COUNT = 3
SEGMENTS = 180
TAU = math.pi * 2.0

# Colors are RGB floats.
SKY = (0.42, 0.70, 0.91)
GRASS = (0.16, 0.43, 0.20)
ROAD = (0.18, 0.19, 0.21)
WHITE = (0.92, 0.92, 0.88)
YELLOW = (1.0, 0.78, 0.12)


def clamp(value, low, high):
    return max(low, min(high, value))


def wrap_angle(angle):
    return angle % TAU


def angle_distance(a, b):
    """Smallest absolute difference between two angles."""
    return abs((a - b + math.pi) % TAU - math.pi)


def track_position(angle, lane=0.0):
    """Return X,Z on an oval track. lane=0 is road center."""
    a = TRACK_A + lane
    b = TRACK_B + lane * (TRACK_B / TRACK_A)
    return a * math.cos(angle), b * math.sin(angle)


def tangent_yaw(angle):
    """Yaw angle in degrees, aligned with the tangent of the oval."""
    dx = -TRACK_A * math.sin(angle)
    dz = TRACK_B * math.cos(angle)
    # OpenGL car forward direction is local +Z.
    return math.degrees(math.atan2(dx, dz))


def setup_lighting():
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glEnable(GL_COLOR_MATERIAL)
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
    glLightfv(GL_LIGHT0, GL_POSITION, (0.2, 1.0, 0.4, 0.0))
    glLightfv(GL_LIGHT0, GL_AMBIENT, (0.42, 0.42, 0.42, 1.0))
    glLightfv(GL_LIGHT0, GL_DIFFUSE, (0.82, 0.82, 0.82, 1.0))
    glShadeModel(GL_SMOOTH)


def draw_cube():
    """Draw a unit cube centered at origin; scale it to make objects."""
    glBegin(GL_QUADS)
    # Front (+Z)
    glNormal3f(0, 0, 1)
    glVertex3f(-0.5, -0.5, 0.5); glVertex3f(0.5, -0.5, 0.5)
    glVertex3f(0.5, 0.5, 0.5); glVertex3f(-0.5, 0.5, 0.5)
    # Back (-Z)
    glNormal3f(0, 0, -1)
    glVertex3f(0.5, -0.5, -0.5); glVertex3f(-0.5, -0.5, -0.5)
    glVertex3f(-0.5, 0.5, -0.5); glVertex3f(0.5, 0.5, -0.5)
    # Left (-X)
    glNormal3f(-1, 0, 0)
    glVertex3f(-0.5, -0.5, -0.5); glVertex3f(-0.5, -0.5, 0.5)
    glVertex3f(-0.5, 0.5, 0.5); glVertex3f(-0.5, 0.5, -0.5)
    # Right (+X)
    glNormal3f(1, 0, 0)
    glVertex3f(0.5, -0.5, 0.5); glVertex3f(0.5, -0.5, -0.5)
    glVertex3f(0.5, 0.5, -0.5); glVertex3f(0.5, 0.5, 0.5)
    # Top (+Y)
    glNormal3f(0, 1, 0)
    glVertex3f(-0.5, 0.5, 0.5); glVertex3f(0.5, 0.5, 0.5)
    glVertex3f(0.5, 0.5, -0.5); glVertex3f(-0.5, 0.5, -0.5)
    # Bottom (-Y)
    glNormal3f(0, -1, 0)
    glVertex3f(-0.5, -0.5, -0.5); glVertex3f(0.5, -0.5, -0.5)
    glVertex3f(0.5, -0.5, 0.5); glVertex3f(-0.5, -0.5, 0.5)
    glEnd()


def cube_at(pos, scale, color, yaw=0.0):
    """Translate -> rotate -> scale: model a cube-based 3D object."""
    glPushMatrix()
    glTranslatef(pos[0], pos[1], pos[2])
    glRotatef(yaw, 0, 1, 0)
    glScalef(scale[0], scale[1], scale[2])
    glColor3f(*color)
    draw_cube()
    glPopMatrix()


def draw_car(x, z, yaw, color, player=False):
    """Simple car assembled from scaled cubes and four black wheels."""
    glPushMatrix()
    glTranslatef(x, 0.0, z)
    glRotatef(yaw, 0, 1, 0)

    # Main chassis and bonnet
    cube_at((0, 0.62, 0), (2.0, 0.62, 3.5), color)
    cube_at((0, 1.04, -0.32), (1.48, 0.55, 1.65), tuple(min(1.0, c * 1.18) for c in color))
    # Dark windscreen/roof section
    cube_at((0, 1.37, 0.18), (1.18, 0.42, 1.10), (0.10, 0.16, 0.19))
    # Headlights and rear lights
    cube_at((-0.66, 0.72, 1.77), (0.36, 0.18, 0.08), (1.0, 0.92, 0.58))
    cube_at((0.66, 0.72, 1.77), (0.36, 0.18, 0.08), (1.0, 0.92, 0.58))
    cube_at((-0.68, 0.70, -1.77), (0.34, 0.18, 0.08), (0.92, 0.08, 0.06))
    cube_at((0.68, 0.70, -1.77), (0.34, 0.18, 0.08), (0.92, 0.08, 0.06))

    # Wheels are cubes for a lightweight, dependency-free model.
    for wx in (-0.98, 0.98):
        for wz in (-1.08, 1.08):
            cube_at((wx, 0.38, wz), (0.36, 0.60, 0.72), (0.045, 0.045, 0.05))
            cube_at((wx * 1.01, 0.39, wz), (0.38, 0.20, 0.30), (0.28, 0.29, 0.31))
    if player:
        # Small roof stripe makes the player's car easy to identify.
        cube_at((0, 1.60, 0.18), (0.18, 0.045, 1.05), (1.0, 1.0, 1.0))
    glPopMatrix()


def draw_ground():
    glDisable(GL_LIGHTING)
    glColor3f(*GRASS)
    glBegin(GL_QUADS)
    glVertex3f(-150, -0.12, -150); glVertex3f(150, -0.12, -150)
    glVertex3f(150, -0.12, 150); glVertex3f(-150, -0.12, 150)
    glEnd()
    glEnable(GL_LIGHTING)


def draw_oval_strip(inner_a, inner_b, outer_a, outer_b, y, color, segments=SEGMENTS):
    """Build an oval ring from many small quadrilateral segments."""
    glColor3f(*color)
    glBegin(GL_QUADS)
    for i in range(segments):
        t1 = TAU * i / segments
        t2 = TAU * (i + 1) / segments
        points = [
            (outer_a * math.cos(t1), y, outer_b * math.sin(t1)),
            (outer_a * math.cos(t2), y, outer_b * math.sin(t2)),
            (inner_a * math.cos(t2), y, inner_b * math.sin(t2)),
            (inner_a * math.cos(t1), y, inner_b * math.sin(t1)),
        ]
        for p in points:
            glVertex3f(*p)
    glEnd()


def draw_track():
    glDisable(GL_LIGHTING)
    # Green infield and wide asphalt oval.
    draw_oval_strip(0.0, 0.0, INNER_A, INNER_B, 0.00, (0.13, 0.39, 0.17))
    draw_oval_strip(INNER_A, INNER_B, OUTER_A, OUTER_B, 0.015, ROAD)
    # Red/white curbs at both edges.
    for i in range(SEGMENTS):
        t1 = TAU * i / SEGMENTS
        t2 = TAU * (i + 1) / SEGMENTS
        c = (0.88, 0.88, 0.84) if (i // 3) % 2 == 0 else (0.78, 0.12, 0.10)
        for aa, bb in ((INNER_A, INNER_B), (OUTER_A, OUTER_B)):
            glColor3f(*c)
            glBegin(GL_QUADS)
            glVertex3f(aa * math.cos(t1), 0.04, bb * math.sin(t1))
            glVertex3f(aa * math.cos(t2), 0.04, bb * math.sin(t2))
            glVertex3f((aa + (0.7 if aa == OUTER_A else -0.7)) * math.cos(t2), 0.04,
                       (bb + (0.7 if bb == OUTER_B else -0.7)) * math.sin(t2))
            glVertex3f((aa + (0.7 if aa == OUTER_A else -0.7)) * math.cos(t1), 0.04,
                       (bb + (0.7 if bb == OUTER_B else -0.7)) * math.sin(t1))
            glEnd()

    # Dashed white center line.
    glColor3f(*WHITE)
    glBegin(GL_QUADS)
    for i in range(SEGMENTS):
        if i % 4 >= 2:
            continue
        t1 = TAU * i / SEGMENTS
        t2 = TAU * (i + 1) / SEGMENTS
        for t, side in ((t1, -0.14), (t2, -0.14), (t2, 0.14), (t1, 0.14)):
            # Slightly offset from centerline to avoid z-fighting.
            aa = TRACK_A + side
            bb = TRACK_B + side * (TRACK_B / TRACK_A)
            glVertex3f(aa * math.cos(t), 0.035, bb * math.sin(t))
    glEnd()

    # Start/finish line crosses the road at angle 0 (right side of oval).
    glColor3f(0.95, 0.95, 0.92)
    glBegin(GL_QUADS)
    for j in range(10):
        x1 = TRACK_A - ROAD_WIDTH / 2 + j * ROAD_WIDTH / 10
        x2 = x1 + ROAD_WIDTH / 10
        col = (0.06, 0.06, 0.06) if j % 2 == 0 else (0.96, 0.96, 0.96)
        glColor3f(*col)
        glVertex3f(TRACK_A + 0.15, 0.05, x1 - TRACK_A)
        glVertex3f(TRACK_A + 0.15, 0.05, x2 - TRACK_A)
        glVertex3f(TRACK_A - 0.15, 0.05, x2 - TRACK_A)
        glVertex3f(TRACK_A - 0.15, 0.05, x1 - TRACK_A)
    glEnd()
    glEnable(GL_LIGHTING)


def draw_tree(x, z, size=1.0):
    # Trunk and foliage, positioned using translation and scaling.
    cube_at((x, 0.8 * size, z), (0.45 * size, 1.6 * size, 0.45 * size), (0.30, 0.16, 0.07))
    cube_at((x, 2.0 * size, z), (1.7 * size, 2.2 * size, 1.7 * size), (0.08, 0.31, 0.10))
    cube_at((x, 2.8 * size, z), (1.15 * size, 1.5 * size, 1.15 * size), (0.12, 0.40, 0.13))


def draw_environment():
    # Repeated trees around the outside of the circuit.
    for i in range(28):
        t = TAU * i / 28
        x = (OUTER_A + 8.0 + (i % 3) * 2.5) * math.cos(t)
        z = (OUTER_B + 8.0 + (i % 3) * 2.0) * math.sin(t)
        draw_tree(x, z, 0.75 + (i % 3) * 0.12)
    # A few simple grandstand blocks on the far side.
    for i in range(8):
        cube_at((-18 + i * 4.8, 1.0, -OUTER_B - 7.0), (4.3, 2.0, 3.0),
                (0.20, 0.25, 0.34))


class Racer:
    def __init__(self, name, color, angle, lane, is_player=False, skill=1.0):
        self.name = name
        self.color = color
        self.angle = angle
        self.lane = lane
        self.is_player = is_player
        self.skill = skill
        self.speed = 0.0
        self.finished = False
        self.finish_time = None
        self.last_angle = angle
        self.lap = 1
        self.checkpoint = 0
        self.lap_start = 0.0
        self.best_lap = None
        self.lap_times = []
        self.total_progress = angle / TAU
        self.steer_visual = 0.0


class RacingGame:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("3D Circuit Racer — Computer Graphics Mini Project")
        pygame.display.set_mode((WIDTH, HEIGHT), DOUBLEBUF | OPENGL)
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("consolas", 22, bold=True)
        self.small_font = pygame.font.SysFont("consolas", 17, bold=True)
        self.big_font = pygame.font.SysFont("consolas", 48, bold=True)
        self.init_gl()
        self.reset()

    def init_gl(self):
        glViewport(0, 0, WIDTH, HEIGHT)
        glClearColor(*SKY, 1.0)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)
        glEnable(GL_NORMALIZE)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(58.0, WIDTH / float(HEIGHT), 0.1, 350.0)
        glMatrixMode(GL_MODELVIEW)
        setup_lighting()

    def reset(self):
        self.player = Racer("YOU", (0.08, 0.34, 0.95), 0.0, 0.0, True)
        self.ai = [
            Racer("RIVAL 1", (0.88, 0.10, 0.08), -0.25, -2.4, skill=0.92),
            Racer("RIVAL 2", (0.95, 0.66, 0.06), -0.52, 2.4, skill=1.02),
            Racer("RIVAL 3", (0.55, 0.12, 0.80), -0.80, 0.0, skill=0.97),
        ]
        self.racers = [self.player] + self.ai
        self.state = "ready"      # ready, countdown, racing, paused, finished
        self.countdown = 3.0
        self.elapsed = 0.0
        self.race_time = 0.0
        self.collision_flash = 0.0
        self.message = ""
        self.message_time = 0.0
        self.camera_mode = 0
        self.final_position = None
        self.start_ticks = 0.0

    def begin_countdown(self):
        if self.state == "ready":
            self.state = "countdown"
            self.countdown = 3.0

    def update(self, dt, keys):
        if self.state == "ready":
            return
        if self.state == "countdown":
            self.countdown -= dt
            if self.countdown <= 0:
                self.state = "racing"
                self.elapsed = 0.0
                self.player.lap_start = 0.0
                for r in self.ai:
                    r.lap_start = 0.0
            return
        if self.state != "racing":
            return

        self.elapsed += dt
        self.collision_flash = max(0.0, self.collision_flash - dt)
        self.message_time = max(0.0, self.message_time - dt)

        # Player acceleration, braking, and natural drag.
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            self.player.speed += ACCELERATION * dt
        elif keys[pygame.K_s] or keys[pygame.K_DOWN]:
            self.player.speed -= BRAKING * dt
        else:
            if self.player.speed > 0:
                self.player.speed = max(0.0, self.player.speed - DRAG * dt)
            elif self.player.speed < 0:
                self.player.speed = min(0.0, self.player.speed + DRAG * dt)
        self.player.speed = clamp(self.player.speed, -5.0, MAX_SPEED)

        steer = 0.0
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            steer += 1.0
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            steer -= 1.0
        # Steering shifts the car across the track; speed affects turning response.
        self.player.lane += steer * STEER_RATE * dt * (0.55 + abs(self.player.speed) / MAX_SPEED)
        self.player.lane = clamp(self.player.lane, -LANE_LIMIT, LANE_LIMIT)
        self.player.steer_visual = steer

        # Forward progress around the oval. Slow reverse moves backwards.
        self.player.angle = wrap_angle(self.player.angle + self.player.speed * dt / TRACK_A)
        self.update_laps(self.player)

        # AI rivals drive at slightly different speeds and gently vary their lanes.
        for i, rival in enumerate(self.ai):
            target_speed = MAX_SPEED * rival.skill * (0.91 + 0.05 * math.sin(self.elapsed * 0.55 + i))
            rival.speed += clamp(target_speed - rival.speed, -8.0 * dt, 8.0 * dt)
            rival.angle = wrap_angle(rival.angle + rival.speed * dt / TRACK_A)
            rival.lane = (2.1 * math.sin(self.elapsed * 0.42 + i * 2.1))
            self.update_laps(rival)

        self.handle_collisions()
        # Race ends as soon as player completes the target laps.
        if self.player.finished:
            self.state = "finished"
            self.final_position = self.get_position(self.player)
            return
        # If an AI completes first, keep the race going until player finishes,
        # but the HUD will show its finished state and position.

    def update_laps(self, racer):
        old = racer.angle
        # Checkpoint sectors are updated by angle, so the HUD can show progress.
        racer.checkpoint = int((racer.angle / TAU) * 4) % 4
        # A lap is counted only when crossing the start/finish line in forward direction.
        if racer.last_angle > 5.35 and racer.angle < 0.9 and racer.speed > 0:
            lap_duration = self.elapsed - racer.lap_start
            if lap_duration > 2.0:
                racer.lap_times.append(lap_duration)
                racer.best_lap = lap_duration if racer.best_lap is None else min(racer.best_lap, lap_duration)
            racer.lap += 1
            racer.lap_start = self.elapsed
            if racer.lap > TOTAL_LAPS:
                racer.finished = True
                racer.finish_time = self.elapsed
        racer.last_angle = racer.angle
        racer.total_progress = (racer.lap - 1) + racer.angle / TAU

    def handle_collisions(self):
        px, pz = track_position(self.player.angle, self.player.lane)
        for rival in self.ai:
            rx, rz = track_position(rival.angle, rival.lane)
            # World-space distance makes collisions intuitive and avoids wrap issues.
            distance = math.sqrt((px - rx) ** 2 + (pz - rz) ** 2)
            if distance < 2.8 and abs(self.player.speed) > 2.0:
                self.player.speed *= 0.55
                self.player.lane = clamp(self.player.lane + (0.7 if self.player.lane <= rival.lane else -0.7),
                                         -LANE_LIMIT, LANE_LIMIT)
                self.collision_flash = 0.35
                self.message = "COLLISION! SPEED REDUCED"
                self.message_time = 1.0

    def get_position(self, racer):
        ordered = sorted(self.racers, key=lambda r: (r.finished, r.total_progress), reverse=True)
        return ordered.index(racer) + 1

    def camera(self):
        x, z = track_position(self.player.angle, self.player.lane)
        yaw = math.radians(tangent_yaw(self.player.angle))
        # Camera follows behind the car; local forward is +Z.
        back_x = -math.sin(yaw) * 10.5
        back_z = -math.cos(yaw) * 10.5
        eye = (x + back_x, 7.0, z + back_z)
        target = (x + math.sin(yaw) * 3.0, 1.0, z + math.cos(yaw) * 3.0)
        return eye, target

    def render_world(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        eye, target = self.camera()
        gluLookAt(eye[0], eye[1], eye[2], target[0], target[1], target[2], 0, 1, 0)

        draw_ground()
        draw_track()
        draw_environment()

        # Draw competitors and the player at their current oval-track positions.
        for racer in self.ai:
            x, z = track_position(racer.angle, racer.lane)
            draw_car(x, z, tangent_yaw(racer.angle), racer.color)
        px, pz = track_position(self.player.angle, self.player.lane)
        draw_car(px, pz, tangent_yaw(self.player.angle), self.player.color, player=True)

    def draw_text(self, x, y, text, font=None, color=(245, 248, 250)):
        if font is None:
            font = self.font
        surface = font.render(text, True, color)
        data = pygame.image.tostring(surface, "RGBA", True)
        glWindowPos2d(x, HEIGHT - y - surface.get_height())
        glDrawPixels(surface.get_width(), surface.get_height(), GL_RGBA, GL_UNSIGNED_BYTE, data)

    def draw_hud(self):
        # HUD uses pixel coordinates in an orthographic overlay, independent of 3D camera.
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, WIDTH, 0, HEIGHT, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_LIGHTING)

        # Semi-transparent panels are represented by dark opaque rectangles for compatibility.
        glColor3f(0.035, 0.055, 0.075)
        glBegin(GL_QUADS)
        glVertex2f(18, HEIGHT - 150); glVertex2f(335, HEIGHT - 150)
        glVertex2f(335, HEIGHT - 18); glVertex2f(18, HEIGHT - 18)
        glVertex2f(WIDTH - 310, HEIGHT - 120); glVertex2f(WIDTH - 18, HEIGHT - 120)
        glVertex2f(WIDTH - 18, HEIGHT - 18); glVertex2f(WIDTH - 310, HEIGHT - 18)
        glEnd()

        position = self.get_position(self.player)
        self.draw_text(32, 28, "3D CIRCUIT RACER", self.small_font, (100, 205, 255))
        self.draw_text(32, 56, f"LAP: {min(self.player.lap, TOTAL_LAPS)}/{TOTAL_LAPS}")
        self.draw_text(32, 84, f"POSITION: {position}/{len(self.racers)}")
        self.draw_text(32, 112, f"TIME: {self.format_time(self.elapsed)}")
        self.draw_text(WIDTH - 290, 28, f"SPEED: {int(max(0, self.player.speed) * 6)} km/h")
        self.draw_text(WIDTH - 290, 58, f"CHECKPOINT: {self.player.checkpoint + 1}/4")
        best = self.player.best_lap
        self.draw_text(WIDTH - 290, 88, "BEST LAP: " + (self.format_time(best) if best else "--:--.--"), self.small_font)

        # Simple speed bar.
        bar_x, bar_y, bar_w, bar_h = WIDTH - 290, 132, 240, 12
        glColor3f(0.18, 0.22, 0.25)
        glBegin(GL_QUADS)
        glVertex2f(bar_x, bar_y); glVertex2f(bar_x + bar_w, bar_y)
        glVertex2f(bar_x + bar_w, bar_y + bar_h); glVertex2f(bar_x, bar_y + bar_h)
        glEnd()
        glColor3f(0.12, 0.78, 0.42)
        fill = bar_w * clamp(self.player.speed / MAX_SPEED, 0, 1)
        glBegin(GL_QUADS)
        glVertex2f(bar_x, bar_y); glVertex2f(bar_x + fill, bar_y)
        glVertex2f(bar_x + fill, bar_y + bar_h); glVertex2f(bar_x, bar_y + bar_h)
        glEnd()

        # Position table on the lower-left.
        glColor3f(0.035, 0.055, 0.075)
        glBegin(GL_QUADS)
        glVertex2f(18, 18); glVertex2f(265, 18)
        glVertex2f(265, 140); glVertex2f(18, 140)
        glEnd()
        self.draw_text(32, HEIGHT - 171, "RACE ORDER", self.small_font, (100, 205, 255))
        ordered = sorted(self.racers, key=lambda r: (r.finished, r.total_progress), reverse=True)
        for i, racer in enumerate(ordered):
            marker = ">" if racer is self.player else " "
            lap_text = "FIN" if racer.finished else f"L{min(racer.lap, TOTAL_LAPS)}"
            self.draw_text(32, HEIGHT - 197 - i * 22, f"{marker} {i+1}. {racer.name:<8} {lap_text}", self.small_font,
                           (255, 230, 120) if racer is self.player else (225, 230, 235))

        if self.message_time > 0:
            self.draw_text(WIDTH // 2 - 190, 145, self.message, self.font, (255, 100, 80))

        if self.state in ("ready", "countdown", "paused", "finished"):
            glColor3f(0.015, 0.025, 0.04)
            glBegin(GL_QUADS)
            glVertex2f(0, 0); glVertex2f(WIDTH, 0)
            glVertex2f(WIDTH, HEIGHT); glVertex2f(0, HEIGHT)
            glEnd()
            if self.state == "ready":
                self.draw_text(WIDTH // 2 - 245, 215, "3D CIRCUIT RACER", self.big_font, (90, 200, 255))
                self.draw_text(WIDTH // 2 - 205, 300, "Press ENTER to start", self.font)
                self.draw_text(WIDTH // 2 - 250, 345, "WASD / ARROWS = DRIVE   SPACE = PAUSE   R = RESTART", self.small_font)
                self.draw_text(WIDTH // 2 - 180, 390, "Complete 3 laps and finish first!", self.small_font, (255, 220, 110))
            elif self.state == "countdown":
                number = max(1, int(math.ceil(self.countdown)))
                self.draw_text(WIDTH // 2 - 35, 235, str(number), self.big_font, (255, 220, 90))
                self.draw_text(WIDTH // 2 - 110, 310, "GET READY!", self.font)
            elif self.state == "paused":
                self.draw_text(WIDTH // 2 - 105, 245, "PAUSED", self.big_font, (255, 220, 90))
                self.draw_text(WIDTH // 2 - 160, 325, "Press SPACE to continue", self.font)
                self.draw_text(WIDTH // 2 - 125, 370, "Press R to restart", self.small_font)
            elif self.state == "finished":
                result = "YOU WIN!" if self.final_position == 1 else f"FINISHED: POSITION {self.final_position}"
                self.draw_text(WIDTH // 2 - 210, 215, "RACE COMPLETE", self.big_font, (90, 200, 255))
                self.draw_text(WIDTH // 2 - 180, 300, result, self.font, (255, 220, 90))
                self.draw_text(WIDTH // 2 - 145, 350, "TIME: " + self.format_time(self.elapsed), self.font)
                self.draw_text(WIDTH // 2 - 155, 410, "Press R to race again", self.small_font)
                self.draw_text(WIDTH // 2 - 105, 445, "ESC to quit", self.small_font)

        glEnable(GL_LIGHTING)
        glEnable(GL_DEPTH_TEST)
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)

    @staticmethod
    def format_time(seconds):
        if seconds is None:
            return "--:--.--"
        seconds = max(0.0, seconds)
        mins = int(seconds // 60)
        secs = seconds % 60
        return f"{mins:02d}:{secs:05.2f}"

    def run(self):
        running = True
        while running:
            dt = min(self.clock.tick(FPS) / 1000.0, 0.04)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_RETURN:
                        self.begin_countdown()
                    elif event.key == pygame.K_r:
                        self.reset()
                    elif event.key == pygame.K_SPACE:
                        if self.state == "racing":
                            self.state = "paused"
                        elif self.state == "paused":
                            self.state = "racing"
            keys = pygame.key.get_pressed()
            self.update(dt, keys)
            self.render_world()
            self.draw_hud()
            pygame.display.flip()

        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    RacingGame().run()
