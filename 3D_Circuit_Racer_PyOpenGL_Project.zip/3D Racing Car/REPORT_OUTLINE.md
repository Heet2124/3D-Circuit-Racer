# Mini Project Report Outline: 3D Circuit Racer

## Title
3D Circuit Racer using Python, Pygame and PyOpenGL

## Aim
To design and implement a basic 3D racing game and demonstrate Computer Graphics transformations, perspective projection, camera positioning, depth testing, lighting and animation.

## Software requirements
- Python 3.10+
- Pygame
- PyOpenGL
- PyOpenGL_accelerate (optional)
- Windows 10/11 and an OpenGL-compatible graphics driver

## Abstract
The project is a 3D racing game in which the player drives a car around a closed oval circuit against three computer-controlled competitors. The game includes a countdown, timer, lap counter, checkpoint sectors, race position, speed display, collision response, camera tracking, pause and restart functions. The visual scene is built from basic geometric primitives to make the graphics techniques easy to study.

## Modules
1. **Initialization:** creates the Pygame window and configures OpenGL.
2. **Track and environment:** draws the ground, oval road, lane markings, curbs, trees and grandstands.
3. **Car model:** combines scaled cubes to form the chassis, roof, lights and wheels.
4. **Player controls:** updates speed and lateral steering from keyboard input.
5. **AI competitors:** moves three rivals around the circuit at slightly different speeds.
6. **Lap and checkpoint system:** detects start/finish crossings and divides each lap into four sectors.
7. **Collision detection:** measures the distance between the player and rival cars and reduces speed on contact.
8. **Camera and HUD:** follows the player and displays race information.
9. **Game states:** start screen, countdown, racing, pause and finish.

## Computer Graphics functions
- `glTranslatef()` — translation
- `glRotatef()` — rotation
- `glScalef()` — scaling
- `gluPerspective()` — perspective projection
- `gluLookAt()` — viewing/camera transformation
- `glEnable(GL_DEPTH_TEST)` — depth testing
- `glBegin()` / `glEnd()` — specify basic polygon geometry
- `glColor3f()` — assign object color
- `glLightfv()` — set lighting properties

## Algorithm
1. Initialize Pygame and OpenGL.
2. Set up projection, depth testing and lighting.
3. Create the player and three AI racers.
4. Repeat each frame:
   - Read keyboard and window events.
   - Update countdown and game state.
   - Update speed, steering and track progress.
   - Move the AI racers.
   - Check lap crossings and collisions.
   - Draw the 3D world and cars.
   - Draw the HUD.
   - Swap the display buffers.
5. Stop when the player closes the window or presses Esc.

## Viva questions and short answers
**1. What is PyOpenGL?**  
PyOpenGL is a Python binding that allows Python programs to use OpenGL graphics functions.

**2. What is translation?**  
Translation changes an object's position. `glTranslatef(x, y, z)` shifts an object along the X, Y and Z axes.

**3. What is rotation?**  
Rotation changes an object's orientation. `glRotatef(angle, x, y, z)` rotates it around the specified axis.

**4. What is scaling?**  
Scaling changes an object's size. `glScalef(sx, sy, sz)` scales its width, height and depth.

**5. Why is perspective projection used?**  
It makes distant objects appear smaller than nearby objects, creating depth.

**6. What is the depth buffer?**  
It stores depth information so the renderer can decide which surfaces are visible.

**7. What does `gluLookAt()` do?**  
It sets the camera position, the point it looks at, and the up direction.

**8. How is a car made?**  
The car is assembled from cubes. Translation places each part, scaling sets its dimensions, and rotation orients the whole car along the track.

**9. How does collision detection work?**  
The program calculates the distance between the player and each AI car. If the distance is below a threshold, the player's speed is reduced.

**10. How does the lap counter work?**  
The game checks whether a racer moved from the end of the angle range back to the beginning while moving forward. That indicates a start/finish crossing.

**11. Why use delta time (`dt`)?**  
It makes movement depend on elapsed time instead of the number of frames rendered.

**12. How does the AI work?**  
Each competitor moves around the oval at a target speed with small speed and lane variations.

## Limitations and future scope
- The oval circuit is an intentionally simple track.
- AI behavior is rule-based rather than path-planning.
- Car models use cubes rather than imported meshes.
- Future work could add sound, textures, multiple tracks, improved physics and a high-score table.
